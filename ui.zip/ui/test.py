# freeze_cam.py
import sys, time, argparse, platform
import cv2
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QImage, QPixmap

def open_capture(index: int, width=1280, height=720, fps=30):
    """按平台选择合适后端并打开摄像头；返回 (cap, info_str)"""
    sysname = platform.system()
    backends = []
    if sysname == "Windows":
        backends = [cv2.CAP_DSHOW, cv2.CAP_MSMF]
    elif sysname == "Darwin":
        backends = [cv2.CAP_AVFOUNDATION]
    else:
        backends = [cv2.CAP_V4L2]

    tried = []
    for be in backends:
        cap = cv2.VideoCapture(index, be)
        tried.append(f"idx={index}, backend={be}")
        if not cap.isOpened():
            cap.release()
            continue

        # 常见 UVC 组合：MJPG + 720/1080p 流畅
        try: cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        except Exception: pass
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        cap.set(cv2.CAP_PROP_FPS, fps)
        try: cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception: pass
        try: cap.set(cv2.CAP_PROP_CONVERT_RGB, 1)
        except Exception: pass

        # 预热（避免首帧卡死）
        t0, ok_cnt = time.perf_counter(), 0
        while time.perf_counter() - t0 < 1.5:
            ok, frame = cap.read()
            if ok and frame is not None:
                ok_cnt += 1
                if ok_cnt >= 3:
                    return cap, f"Opened: idx={index}, backend={be}, {width}x{height}"
            time.sleep(0.02)

        cap.release()

    return None, "Failed to open camera. Tried: " + " | ".join(tried)


class CamWindow(QWidget):
    def __init__(self, cam_index=1):
        super().__init__()
        self.setWindowTitle("外置摄像头预览（点击“定格/继续”切换）")
        self.resize(960, 620)

        # UI
        self.video_label = QLabel("摄像头未启动")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("font-size:16px;color:#4080ff;")

        self.status_label = QLabel("状态：准备就绪")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("font-size:13px;color:#666;")

        self.btn_toggle = QPushButton("定格")
        self.btn_toggle.setMinimumHeight(40)
        self.btn_toggle.clicked.connect(self.toggle_freeze)

        self.btn_quit = QPushButton("退出")
        self.btn_quit.setMinimumHeight(40)
        self.btn_quit.clicked.connect(self.close)

        hl = QHBoxLayout()
        hl.addWidget(self.btn_toggle)
        hl.addWidget(self.btn_quit)

        layout = QVBoxLayout()
        layout.addWidget(self.video_label, 1)
        layout.addLayout(hl)
        layout.addWidget(self.status_label)
        self.setLayout(layout)

        # 状态
        self.frozen = False
        self.last_frame_rgb = None

        # 打开摄像头（默认外置索引 1）
        self.cap, info = open_capture(cam_index, width=1280, height=720, fps=30)
        self.status_label.setText(f"状态：{info}")
        if self.cap is None:
            QMessageBox.critical(self, "错误", info)
            self.btn_toggle.setEnabled(False)
            return

        # 定时器拉帧
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(0)  # 处理完一帧立即请求下一帧，不卡队列

    def toggle_freeze(self):
        self.frozen = not self.frozen
        self.btn_toggle.setText("继续" if self.frozen else "定格")
        self.status_label.setText("状态：已定格当前画面" if self.frozen else "状态：实时预览中")

    def update_frame(self):
        """实时拉帧；若处于定格状态，仅重复显示上一帧"""
        if self.frozen:
            if self.last_frame_rgb is not None:
                self.show_rgb(self.last_frame_rgb)
            return

        if self.cap is None:
            return

        ok, frame_bgr = self.cap.read()
        if not ok or frame_bgr is None:
            self.status_label.setText("状态：读取帧失败，稍后重试…")
            return

        # 转 RGB 并深拷贝（避免 Qt 访问临时内存导致崩溃）
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        self.last_frame_rgb = frame_rgb.copy()
        self.show_rgb(self.last_frame_rgb)

    def show_rgb(self, rgb):
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch*w, QImage.Format_RGB888).copy()
        pix = QPixmap.fromImage(qimg).scaled(
            self.video_label.width(), self.video_label.height(),
            Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self.video_label.setPixmap(pix)

    def closeEvent(self, e):
        try:
            if hasattr(self, "timer") and self.timer.isActive():
                self.timer.stop()
        except Exception:
            pass
        try:
            if self.cap is not None:
                self.cap.release()
                self.cap = None
        except Exception:
            pass
        super().closeEvent(e)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=int, default=1, help="摄像头索引（默认 1 为外置）")
    args = parser.parse_args()

    app = QApplication(sys.argv)
    w = CamWindow(cam_index=args.index)
    w.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
