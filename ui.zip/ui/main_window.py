import os
import sys
import cv2
import numpy as np
import math
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QPushButton,
                             QVBoxLayout, QHBoxLayout, QFrame, QSplitter,
                             QGridLayout, QGroupBox, QGraphicsDropShadowEffect)
from PyQt5.QtCore import QTimer, Qt, QSize, QPropertyAnimation, QEasingCurve, QSequentialAnimationGroup, \
    QParallelAnimationGroup, pyqtProperty
from PyQt5.QtGui import (QImage, QPixmap, QFont, QIcon, QColor,
                         QLinearGradient, QPainter, QBrush, QPalette, QRadialGradient, QPen, QPolygonF)
from backend.vision_service import VisionRecognitionService


import serial
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QMessageBox

# ==== 串口屏发送器（Nextion/字符串协议：每条指令以 FF FF FF 结尾）====
import serial
import time

END = b'\xff\xff\xff'

class ScreenSender:
    def __init__(self, port="COM3", baud=115200, encoding="gbk"):
        self.port = port
        self.baud = baud
        self.encoding = encoding
        self.ser = None

        # 你屏幕里的控件名称（按你的HMI工程修改）
        self.comp_color   = "tColor"    # 颜色显示文本控件
        self.comp_pattern = "tPattern"  # 类别/模式显示文本控件
        self.comp_angle   = "tAngle"    # 角度显示文本控件（文本方式最兼容）

    def open(self):
        if self.ser and self.ser.is_open:
            return True
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.1, write_timeout=0.2)
            time.sleep(0.1)
            # 建议打开回执，方便调试；即使没回执，也不影响发送
            self.send_cmd("bkcmd=2")
            return True
        except Exception as e:
            print(f"[ScreenSender] 打开串口失败: {e}")
            self.ser = None
            return False

    def close(self):
        try:
            if self.ser and self.ser.is_open:
                self.ser.close()
        except:
            pass

    def send_cmd(self, text_cmd: str):
        """发送纯文本命令 + FF FF FF；例如 t0.txt="OK" / page 0 / get bkcmd"""
        if not (self.ser and self.ser.is_open):
            return False
        payload = text_cmd.encode(self.encoding) + END
        # 可选：打印观测
        # print("--> TX:", payload.hex(" "), "|", text_cmd)
        try:
            self.ser.write(payload); self.ser.flush()
            return True
        except Exception as e:
            print(f"[ScreenSender] 发送失败: {e}")
            return False

    def set_text(self, comp: str, value: str):
        # 对于中文，若你屏用 GBK，初始化时把 encoding 换成 'gbk'
        # 注意屏字体要支持相应字符集
        # value 里如有引号建议做简单转义
        safe = value.replace('"', '\\"')
        return self.send_cmd(f'{comp}.txt="{safe}"')

    def set_angle_text(self, comp: str, angle: float):
        # 统一用文本显示角度，兼容所有屏
        return self.set_text(comp, f"{angle:.1f}°")

    def push_results(self, color: str, pattern: str, angle: float):
        """一次性把三个结果写回屏幕控件"""
        ok = True
        ok &= self.set_text(self.comp_color, color if color else "未知")
        ok &= self.set_text(self.comp_pattern, pattern if pattern else "未知")
        ok &= self.set_angle_text(self.comp_angle, float(angle) if angle is not None else 0.0)
        return ok


class SerialBridge(QThread):
    start_signal = pyqtSignal()  # 当收到启动信号时，触发信号
    log_signal = pyqtSignal(str)

    def __init__(self, port=None, baud=115200, ser=None, parent=None):
        """
        - 如果 ser 已传入（外部已打开），则直接复用，不再自行打开/关闭。
        - 否则按 port/baud 自行打开。
        """
        super().__init__(parent)
        self.port = port
        self.baud = baud
        self.ser = ser
        self._own = (ser is None)     # 我是否自己管理串口生命周期
        self._stop = False

    def open_port(self):
        if self.ser and getattr(self.ser, "is_open", False):
            self.log_signal.emit("串口已复用（外部提供）")
            return True
        try:
            import serial
            self.ser = serial.Serial(self.port, self.baud, timeout=0.1, write_timeout=0.2)
            self.log_signal.emit(f"串口 {self.port} 已打开")
            return True
        except Exception as e:
            self.log_signal.emit(f"串口打开失败: {e}")
            return False

    def close_port(self):
        if self._own and self.ser and self.ser.is_open:
            self.ser.close()
            self.log_signal.emit(f"串口 {self.port} 已关闭")

    def stop(self):
        self._stop = True

    def run(self):
        if not self.open_port():
            return

        buf = bytearray()
        END = b'\xff\xff\xff'
        while not self._stop:
            try:
                n = self.ser.in_waiting
                if n:
                    buf += self.ser.read(n)
                    while True:
                        i = buf.find(END)
                        if i == -1:
                            break
                        frame = bytes(buf[:i])
                        buf = buf[i + 3:]

                        # 启动信号 0x90
                        if frame == b'\x90':
                            self.log_signal.emit("收到启动识别信号（0x90）")
                            self.start_signal.emit()
                            # 不退出，继续监听下一次
                            continue

                        # Nextion 触摸事件 0x65 <page> <comp> <event>
                        if len(frame) >= 4 and frame[0] == 0x65:
                            p, c, ev = frame[1], frame[2], frame[3]
                            self.log_signal.emit(f"触摸事件 page={p} comp={c} ev={ev}")
                            # 可在此判断特定组件触发 start_signal
                            # if p==0 and c==3 and ev==1: self.start_signal.emit()
                            continue

                        self.log_signal.emit(f"其他帧: {frame.hex(' ')}")
                else:
                    self.msleep(10)
            except Exception as e:
                self.log_signal.emit(f"监听异常: {e}")
                self.msleep(50)

        self.close_port()


class NeuralNetworkWidget(QWidget):
    """神经网络实时动画组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(300, 200)
        self.nodes = []
        self.connections = []
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.update_animation)
        self.animation_timer.start(50)  # 每 50ms 更新
        self.pulse_offset = 0  # 脉冲偏移量
        self.setup_network()

    def setup_network(self):
        """设置网络节点和连接"""
        # 输入层
        for i in range(4):
            self.nodes.append({'x': 30, 'y': 30 + i * 35, 'layer': 0, 'activation': 0.3})

        # 隐藏层
        for i in range(6):
            self.nodes.append({'x': 120, 'y': 15 + i * 25, 'layer': 1, 'activation': 0.5})

        # 第二隐藏层
        for i in range(4):
            self.nodes.append({'x': 210, 'y': 30 + i * 35, 'layer': 2, 'activation': 0.7})

        # 输出层
        for i in range(3):
            self.nodes.append({'x': 270, 'y': 45 + i * 35, 'layer': 3, 'activation': 0.8})

        # 创建连接
        layer_starts = [0, 4, 10, 14]
        layer_sizes = [4, 6, 4, 3]

        for layer in range(3):
            start_idx = layer_starts[layer]
            next_start = layer_starts[layer + 1]
            for i in range(layer_sizes[layer]):
                for j in range(layer_sizes[layer + 1]):
                    self.connections.append({
                        'from': start_idx + i,
                        'to': next_start + j,
                        'weight': np.random.random() * 0.8 + 0.2
                    })

    def update_animation(self):
        """更新动画状态"""
        self.pulse_offset += 0.1

        # 更新节点激活状态
        for i, node in enumerate(self.nodes):
            base_activation = 0.3 + 0.4 * math.sin(self.pulse_offset + i * 0.3)
            node['activation'] = max(0.1, base_activation)

        self.update()

    def paintEvent(self, event):
        """绘制网络、连接和激活效果"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制连接线（随激活变换透明度和颜色）
        for conn in self.connections:
            from_node = self.nodes[conn['from']]
            to_node = self.nodes[conn['to']]
            weight = conn['weight']

            # 根据激活和权重设置颜色强度
            alpha = int(weight * from_node['activation'] * 150 + 50)
            color = QColor(0, 240, 255, alpha)
            pen = QPen(color, 1)
            painter.setPen(pen)
            painter.drawLine(from_node['x'], from_node['y'], to_node['x'], to_node['y'])

        # 绘制节点
        for node in self.nodes:
            radius = 4 + node['activation'] * 3
            intensity = int(node['activation'] * 255)

            # 发光效果
            glow_color = QColor(0, 240, 255, 80)
            painter.setBrush(QBrush(glow_color))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(node['x'] - radius - 2, node['y'] - radius - 2,
                                (radius + 2) * 2, (radius + 2) * 2)

            # 节点核心
            core_color = QColor(255, 255, 255, intensity)
            painter.setBrush(QBrush(core_color))
            painter.drawEllipse(node['x'] - radius, node['y'] - radius,
                                radius * 2, radius * 2)


class AnimatedButton(QPushButton):
    """带动画效果的按钮"""

    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.hover_animation = QPropertyAnimation(self, b"geometry")
        self.hover_animation.setDuration(200)
        self.hover_animation.setEasingCurve(QEasingCurve.OutCubic)
        self.original_geometry = None
        self.is_hovering = False

        # 光晕效果
        self.glow_effect = QGraphicsDropShadowEffect()
        self.glow_effect.setBlurRadius(20)
        self.glow_effect.setOffset(0, 0)
        self.glow_effect.setColor(QColor(0, 240, 255, 100))
        self.setGraphicsEffect(self.glow_effect)

    def enterEvent(self, event):
        """鼠标进入时触发动画"""
        if not self.is_hovering:
            self.is_hovering = True
            if self.original_geometry is None:
                self.original_geometry = self.geometry()

            expanded = self.original_geometry.adjusted(-3, -3, 3, 3)
            self.hover_animation.setStartValue(self.geometry())
            self.hover_animation.setEndValue(expanded)
            self.hover_animation.start()

            # 增强光晕
            self.glow_effect.setBlurRadius(30)
            self.glow_effect.setColor(QColor(0, 240, 255, 150))

        super().enterEvent(event)

    def leaveEvent(self, event):
        """鼠标离开时恢复动画"""
        if self.is_hovering:
            self.is_hovering = False
            if self.original_geometry:
                self.hover_animation.setStartValue(self.geometry())
                self.hover_animation.setEndValue(self.original_geometry)
                self.hover_animation.start()

            # 恢复光晕
            self.glow_effect.setBlurRadius(20)
            self.glow_effect.setColor(QColor(0, 240, 255, 100))

        super().leaveEvent(event)


class PulsingLabel(QLabel):
    """脉冲动画标签"""

    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.opacity_animation = QPropertyAnimation(self, b"windowOpacity")
        self.opacity_animation.setDuration(1500)
        self.opacity_animation.setStartValue(0.6)
        self.opacity_animation.setEndValue(1.0)
        self.opacity_animation.setEasingCurve(QEasingCurve.InOutSine)

        # 创建循环动画
        self.animation_group = QSequentialAnimationGroup()
        self.animation_group.addAnimation(self.opacity_animation)

        reverse_animation = QPropertyAnimation(self, b"windowOpacity")
        reverse_animation.setDuration(1500)
        reverse_animation.setStartValue(1.0)
        reverse_animation.setEndValue(0.6)
        reverse_animation.setEasingCurve(QEasingCurve.InOutSine)
        self.animation_group.addAnimation(reverse_animation)

        self.animation_group.setLoopCount(-1)  # 无限循环

    def start_pulsing(self):
        """开始脉冲动画"""
        self.animation_group.start()

    def stop_pulsing(self):
        """停止脉冲动画"""
        self.animation_group.stop()
        self.setWindowOpacity(1.0)


class GradientFrame(QFrame):
    """带有渐变背景的框架"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(200)
        self.animation_offset = 0

        # 定时器定期更新背景效果
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.update_gradient)
        self.animation_timer.start(100)

    def update_gradient(self):
        """更新背景动画参数"""
        self.animation_offset += 0.02
        self.update()

    def paintEvent(self, event):
        """绘制渐变背景和网格线"""
        painter = QPainter(self)

        # 动态径向渐变
        gradient = QRadialGradient(
            self.width() * (0.5 + 0.2 * math.sin(self.animation_offset)),
            self.height() * (0.5 + 0.1 * math.cos(self.animation_offset * 1.3)),
            min(self.width(), self.height()) * 0.8
        )

        color1_intensity = int(30 + 10 * math.sin(self.animation_offset))
        color2_intensity = int(15 + 5 * math.cos(self.animation_offset * 0.7))

        gradient.setColorAt(0, QColor(color1_intensity, color1_intensity, color1_intensity + 20))  # 中心颜色
        gradient.setColorAt(0.7, QColor(10, 10, 25))  # 中间颜色
        gradient.setColorAt(1, QColor(color2_intensity, color2_intensity, color2_intensity + 15))  # 边缘颜色

        painter.fillRect(self.rect(), QBrush(gradient))

        # 绘制网格
        pen = QPen(QColor(0, 240, 255, 30))
        pen.setWidth(1)
        painter.setPen(pen)

        grid_size = 40
        for i in range(0, self.width(), grid_size):
            painter.drawLine(i, 0, i, self.height())

        for i in range(0, self.height(), grid_size):
            painter.drawLine(0, i, self.width(), i)

        super().paintEvent(event)


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # ===== 窗口与样式 =====
        self.setWindowTitle("智能翻转机构视觉识别系统")
        self.setGeometry(100, 100, 1400, 800)
        self.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0A0A15, stop:0.5 #050508, stop:1 #000000);
                color: #E8E8FF;
                font-family: 'SF Pro Display', 'Segoe UI', sans-serif;
            }

            QLabel#title {
                font-size: 36px;
                font-weight: 300;
                color: #FFFFFF;
                letter-spacing: 2px;
                background: none;
                border: none;
            }

            QLabel#result_label {
                font-size: 20px;
                font-weight: 400;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(0, 240, 255, 0.1),
                    stop:0.5 rgba(0, 120, 180, 0.15),
                    stop:1 rgba(0, 60, 120, 0.1));
                border: 2px solid rgba(0, 240, 255, 0.3);
                border-radius: 15px;
                padding: 20px;
                min-height: 60px;
            }

            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(0, 180, 240, 0.8),
                    stop:1 rgba(0, 120, 180, 0.6));
                color: white;
                border: 2px solid rgba(0, 240, 255, 0.5);
                border-radius: 12px;
                padding: 15px 25px;
                font-size: 16px;
                font-weight: 500;
                min-width: 140px;
                min-height: 50px;
            }

            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(0, 220, 255, 0.9),
                    stop:1 rgba(0, 160, 220, 0.7));
                border-color: rgba(0, 255, 255, 0.8);
            }

            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(0, 140, 200, 0.7),
                    stop:1 rgba(0, 100, 150, 0.5));
            }

            QPushButton#start_button {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(0, 200, 100, 0.8),
                    stop:1 rgba(0, 150, 80, 0.6));
                border-color: rgba(0, 255, 150, 0.5);
            }

            QPushButton#start_button:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(0, 240, 120, 0.9),
                    stop:1 rgba(0, 180, 100, 0.7));
                border-color: rgba(0, 255, 180, 0.8);
            }

            QPushButton#stop_button {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(255, 100, 100, 0.8),
                    stop:1 rgba(200, 60, 60, 0.6));
                border-color: rgba(255, 150, 150, 0.5);
            }

            QPushButton#stop_button:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(255, 140, 140, 0.9),
                    stop:1 rgba(220, 80, 80, 0.7));
                border-color: rgba(255, 180, 180, 0.8);
            }

            QGroupBox {
                border: 2px solid rgba(0, 240, 255, 0.3);
                border-radius: 15px;
                margin-top: 25px;
                font-size: 18px;
                font-weight: 400;
                color: #E8E8FF;
                padding: 15px;
                background: rgba(0, 50, 80, 0.1);
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 15px;
                background: rgba(0, 0, 0, 0.8);
                border-radius: 8px;
            }

            QLabel#process_label {
                min-height: 220px;
                background: rgba(0, 20, 40, 0.3);
                border: 1px solid rgba(0, 180, 220, 0.3);
                border-radius: 10px;
            }

            QSplitter::handle {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(0, 240, 255, 0.3),
                    stop:0.5 rgba(0, 180, 220, 0.5),
                    stop:1 rgba(0, 240, 255, 0.3));
                width: 3px;
                border-radius: 1px;
            }
        """)

        # ===== 识别服务 / 计时器等 =====
        self.recognizer = VisionRecognitionService(angle_model_path=r"proto_angle_final.pt")

        self.cap = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.setInterval(300)

        # ===== 先创建 UI（很关键：确保 status_label 存在后再接收日志） =====
        self.create_widgets()
        self.setup_layout()
        self.setup_connections()

        # ===== 状态变量 =====
        self.preview_running = False
        self.frozen_frame = None
        self._last_frame_bgr = None

        # ===== 串口：先打开发送器（只打开一次端口），再让监听线程复用这个端口 =====
        # 注意：确保 ScreenSender 与 SerialBridge 类已在模块里定义好
        self.screen_sender = ScreenSender(port="COM3", baud=115200, encoding="gbk")  # 如需中文：encoding="gbk"
        self.screen_sender.open()

        # 监听线程复用上面的串口句柄，避免重复打开同一个 COM
        self.serial_bridge = SerialBridge(ser=self.screen_sender.ser)  # 直接传 ser，不再传 port
        self.serial_bridge.start_signal.connect(self.trigger_recognition)
        self.serial_bridge.log_signal.connect(lambda msg: self.status_label.setText(f"状态: {msg}"))
        self.serial_bridge.start()

        # 启动后自动进入实时预览
        QTimer.singleShot(0, self.start_preview)

    def create_widgets(self):
        """创建UI组件"""
        self.title_label = PulsingLabel("智能物料视觉识别系统")
        self.title_label.setObjectName("title")
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setFixedHeight(70)
        self.title_label.start_pulsing()

        # 摄像头显示区域
        self.camera_frame = GradientFrame()
        self.camera_frame.setObjectName("camera_frame")
        camera_layout = QVBoxLayout(self.camera_frame)

        self.camera_label = QLabel()
        self.camera_label.setAlignment(Qt.AlignCenter)
        self.camera_label.setText("🔮 AI视觉系统初始化中...")
        self.camera_label.setStyleSheet("font-size: 22px; color: #80E0FF; font-weight: 300;")
        camera_layout.addWidget(self.camera_label)

        # 识别结果显示区域
        self.result_label = QLabel("🚀 神经网络就绪，等待启动识别...")
        self.result_label.setObjectName("result_label")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setMinimumHeight(100)

        # 处理流程组
        self.process_group = QGroupBox("AI 视觉处理管线")
        process_layout = QGridLayout(self.process_group)

        network_container = QWidget()
        network_layout = QVBoxLayout(network_container)
        self.neural_network = NeuralNetworkWidget()
        network_title = QLabel("神经网络实时状态")
        network_title.setAlignment(Qt.AlignCenter)
        network_title.setStyleSheet("font-size: 14px; color: #80E0FF; margin-bottom: 10px;")
        network_layout.addWidget(network_title)
        network_layout.addWidget(self.neural_network)
        network_layout.setContentsMargins(10, 10, 10, 10)

        self.process_label1 = QLabel("颜色特征提取")
        self.process_label1.setObjectName("process_label")
        self.process_label1.setAlignment(Qt.AlignCenter)

        self.process_label2 = QLabel("模式识别分类")
        self.process_label2.setObjectName("process_label")
        self.process_label2.setAlignment(Qt.AlignCenter)

        self.process_info1 = QLabel("Color Detection")
        self.process_info1.setAlignment(Qt.AlignCenter)
        self.process_info1.setStyleSheet("font-size: 14px; color: #80E0FF; margin-top: 8px; font-weight: 300;")

        self.process_info2 = QLabel("Pattern Classification")
        self.process_info2.setAlignment(Qt.AlignCenter)
        self.process_info2.setStyleSheet("font-size: 14px; color: #80E0FF; margin-top: 8px; font-weight: 300;")

        # 固定尺寸与布局
        self.process_label1.setFixedSize(280, 200)
        self.process_label2.setFixedSize(280, 200)
        self.process_info1.setFixedHeight(30)
        self.process_info2.setFixedHeight(30)

        process_layout.addWidget(network_container, 0, 0, 2, 1)
        process_layout.addWidget(self.process_label1, 0, 1)
        process_layout.addWidget(self.process_info1, 1, 1)
        process_layout.addWidget(self.process_label2, 0, 2)
        process_layout.addWidget(self.process_info2, 1, 2)
        process_layout.setColumnStretch(0, 1)
        process_layout.setColumnStretch(1, 1)
        process_layout.setColumnStretch(2, 1)
        process_layout.setSpacing(20)

        # 控制按钮
        self.start_button = AnimatedButton("启动识别")
        self.start_button.setObjectName("start_button")
        self.start_button.setMinimumHeight(55)

        self.stop_button = AnimatedButton("停止识别")
        self.stop_button.setObjectName("stop_button")
        self.stop_button.setMinimumHeight(55)
        self.stop_button.setEnabled(True)

        self.quit_button = AnimatedButton("退出系统")
        self.quit_button.setMinimumHeight(55)

        # 状态栏
        self.status_label = QLabel("状态: AI模型加载完成 | 神经网络就绪")
        self.status_label.setStyleSheet("""
            font-size: 14px; 
            color: #A0C0FF; 
            padding: 10px;
            background: rgba(0, 60, 120, 0.2);
            border-radius: 8px;
            border: 1px solid rgba(0, 120, 180, 0.3);
        """)

        self.decor_label = QLabel("◦ ◦ ◦  NEURAL  VISION  SYSTEM  ◦ ◦ ◦")
        self.decor_label.setAlignment(Qt.AlignCenter)
        self.decor_label.setStyleSheet("""
            font-size: 16px; 
            letter-spacing: 4px; 
            color: rgba(0, 200, 255, 0.6);
            font-weight: 300;
            margin: 10px 0;
        """)

    def setup_layout(self):
        """设置布局"""
        # 控制按钮布局
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.start_button)
        button_layout.addWidget(self.stop_button)
        button_layout.addWidget(self.quit_button)
        button_layout.setSpacing(25)

        # 右侧面板布局
        right_panel = QVBoxLayout()
        right_panel.addWidget(self.result_label)
        right_panel.addSpacing(25)
        right_panel.addWidget(self.process_group, 1)
        right_panel.addSpacing(25)
        right_panel.addLayout(button_layout)
        right_panel.addSpacing(15)
        right_panel.addWidget(self.status_label)
        right_panel.setContentsMargins(20, 20, 20, 20)

        # 主分割布局
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self.camera_frame)
        right_widget = QWidget()
        right_widget.setLayout(right_panel)
        splitter.addWidget(right_widget)
        splitter.setSizes([900, 500])  # 左右区域初始比例
        splitter.setHandleWidth(3)

        main_layout = QVBoxLayout()
        main_layout.addWidget(self.title_label)
        main_layout.addWidget(self.decor_label)
        main_layout.addWidget(splitter, 1)
        main_layout.setContentsMargins(15, 15, 15, 10)
        main_layout.setSpacing(5)

        self.setLayout(main_layout)

    def setup_connections(self):
        """设置信号连接"""
        self.start_button.clicked.connect(self.freeze_and_infer)
        self.stop_button.clicked.connect(self.resume_preview)
        self.quit_button.clicked.connect(self.close)

    def start_camera(self):
        """启动摄像头和识别"""
        self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # 0/1 視具體攝像頭調整

        if not self.cap.isOpened():
            self.result_label.setText("❌ 无法访问摄像头设备")
            self.status_label.setText("状态: 错误 - 摄像头连接失败")
            return

        self.timer.start()
        self.result_label.setText("🧠 神经网络正在分析...")
        self.status_label.setText("状态: AI视觉系统运行中 | 实时识别激活")

        # 更新按钮状态
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)

    def stop_camera(self):
        """停止摄像头"""
        self.timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None

        self.camera_label.setText("📡 视觉系统已停止")
        self.result_label.setText("⏸️ AI识别系统暂停")
        self.status_label.setText("状态: 神经网络待机 | 准备下次启动")

        # 清除处理图像
        self.process_label1.clear()
        self.process_label1.setText("颜色特征提取")
        self.process_label2.clear()
        self.process_label2.setText("模式识别分类")

        # 更新按钮状态
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)

    def start_preview(self):
        """打开相机，进入实时预览（不做推理）"""
        # 优先外接摄像头 index=1；如需调整可改
        self.cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            self.result_label.setText("❌ 无法访问摄像头设备")
            self.status_label.setText("状态: 错误 - 摄像头连接失败")
            return
        try:
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.cap.set(cv2.CAP_PROP_FPS, 30)

        self.preview_running = True
        self.frozen_frame = None
        self.timer.start(0)
        self.result_label.setText("👀 实时预览中（未开始识别）")
        self.status_label.setText("状态: 摄像头已打开 | 预览运行中")
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(True)

    def resume_preview(self):
        """从定格/识别阶段回到实时预览"""
        if self.cap is None or not self.cap.isOpened():
            self.start_preview()
            return
        self.preview_running = True
        self.frozen_frame = None
        if not self.timer.isActive():
            self.timer.start(0)
        self.result_label.setText("👀 已恢复实时预览")
        self.status_label.setText("状态: 预览运行中")
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(True)

    def freeze_and_infer(self):
        """定格当前画面，并用这一帧做推理；完成后把结果回传串口屏"""
        if self._last_frame_bgr is None:
            self.status_label.setText("状态: 尚未获取到视频帧，无法定格")
            return
        self.frozen_frame = self._last_frame_bgr.copy()
        self.preview_running = False
        if self.timer.isActive():
            self.timer.stop()

        # 显示定格帧
        self._show_bgr_on_label(self.frozen_frame, self.camera_label)

        self.result_label.setText("🧊 画面已定格，开始识别…")
        self.status_label.setText("状态: 推理中…")
        self.start_button.setEnabled(False)
        try:
            result = self.recognizer.predict_all(self.frozen_frame)
            color, color_image = result.get("color", ("未知", None))
            pattern = result.get("pattern", "")
            angle = result.get("angle", 0)

            # 角度数值标准化
            if isinstance(angle, (int, float)):
                angle_val = float(angle)
            else:
                try:
                    angle_val = float(angle)
                except Exception:
                    angle_val = 0.0

            # UI 显示
            display_text = f"""
            <span style='font-size:18px; color:#00E0FF; font-weight:500;'>🎯 AI识别结果&nbsp;&nbsp;</span>
            <span style='color:#80D0FF;'>颜色特征：</span><span style='color:#FFFFFF;'>{color}</span>&nbsp;&nbsp;
            <span style='color:#80D0FF;'>模式分类：</span><span style='color:#FFFFFF;'>{pattern}</span>&nbsp;&nbsp;
            <span style='color:#80D0FF;'>角度检测：</span><span style='color:#FFFFFF;'>{angle_val:.1f}°</span>
            """
            self.result_label.setText(display_text)

            # 过程图（分类）
            if pattern:
                img_path = f"backend/raw/{pattern}/img01.jpg"
                if os.path.exists(img_path):
                    pattern_img = cv2.imread(img_path)
                    self.update_process_image(self.process_label2, pattern_img, pattern)
                else:
                    self.process_label2.setText("⚠️ 分类图像未找到")
                    self.process_info2.setText(pattern or "Unknown")

            # 过程图（颜色）
            if color_image is not None:
                self.update_process_image(self.process_label1, color_image, color)

            # —— 把识别结果回传串口屏（ScreenSender.push_results）——
            try:
                if hasattr(self, "screen_sender") and self.screen_sender:
                    sent_ok = self.screen_sender.push_results(color, pattern, angle_val)
                    if sent_ok:
                        self.status_label.setText("状态: 推理完成（已回传到串口屏）")
                    else:
                        self.status_label.setText("状态: 推理完成（回传串口屏失败，请检查串口/端口占用）")
            except Exception as e:
                self.status_label.setText(f"状态: 串口发送失败 {e}")

        except Exception as e:
            self.result_label.setText(f"❌ 识别失败：{e}")
            self.status_label.setText("状态: 推理异常")
        finally:
            self.stop_button.setEnabled(True)

    def _show_bgr_on_label(self, bgr_image, label):
        """把 BGR 图像显示到 QLabel（深拷贝以避免崩溃）"""
        rgb = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888).copy()
        pixmap = QPixmap.fromImage(qimg).scaled(
            label.width(), label.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        label.setPixmap(pixmap)
        label.setText("")

    def update_frame(self):
        """预览阶段：只读帧并显示；识别阶段：不读帧（维持定格）"""
        if self.cap is None:
            return

        if not self.preview_running:
            if self.frozen_frame is not None:
                self._show_bgr_on_label(self.frozen_frame, self.camera_label)
            return

        ret, frame = self.cap.read()
        if not ret or frame is None:
            self.status_label.setText("状态: 读取视频帧失败…")
            return

        # 缓存当前帧给“定格并推理”用
        self._last_frame_bgr = frame
        self._show_bgr_on_label(frame, self.camera_label)

        # 预览提示
        if "预览" not in self.result_label.text():
            self.result_label.setText("👀 实时预览中（点击“启动识别”将定格并开始推理）")

    def update_process_image(self, label, image, title=None):
        """在标签中显示处理后的图像"""
        if image is None:
            return

        if len(image.shape) == 2:
            # 灰度图
            h, w = image.shape
            qt_image = QImage(image.data, w, h, w, QImage.Format_Grayscale8)
        else:
            # BGR 转 RGB
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            qt_image = QImage(rgb_image.data, w, h, ch * w, QImage.Format_RGB888)

        # 显示
        pixmap = QPixmap.fromImage(qt_image).scaled(
            label.width(), label.height(),
            Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        label.setPixmap(pixmap)

        # 更新信息文本
        if title:
            info_text = f"Pattern: {title}" if label == self.process_label2 else f"Color: {title}"
            if label == self.process_label2:
                self.process_info2.setText(info_text)
            else:
                self.process_info1.setText(info_text)

    def closeEvent(self, event):
        """窗口关闭事件"""
        # 先停线程再关串口，最后释放摄像头
        try:
            if hasattr(self, "serial_bridge") and self.serial_bridge.isRunning():
                self.serial_bridge.stop()
                self.serial_bridge.wait(500)
        except Exception:
            pass

        try:
            if hasattr(self, "screen_sender"):
                self.screen_sender.close()
        except Exception:
            pass

        if self.timer.isActive():
            self.timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None

        event.accept()

    def trigger_recognition(self):
        """接到串口屏启动信号时的处理：提示→启动识别"""
        self.result_label.setText("🚀 收到启动信号，开始识别...")
        self.freeze_and_infer()

    def stop(self):
        """（备用）关闭串口监听线程"""
        if hasattr(self, "serial_bridge") and self.serial_bridge.isRunning():
            self.serial_bridge.stop()
            self.serial_bridge.wait(500)


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 设置现代化字体
    font = QFont("SF Pro Display", 10)
    if not font.exactMatch():
        font = QFont("Segoe UI", 10)
    font.setWeight(QFont.Normal)
    app.setFont(font)

    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
