import serial
import threading

class SerialHandler:
    def __init__(self, port="COM3", baudrate=9600):
        self.ser = serial.Serial(port, baudrate, timeout=1)
        self.callbacks = {}  # {命令类型: 回调函数}
        self.running = False

    def send_command(self, cmd_bytes: bytes):
        self.ser.write(cmd_bytes)

    def register_callback(self, cmd_type: str, callback):
        self.callbacks[cmd_type] = callback

    def start_listening(self):
        self.running = True
        thread = threading.Thread(target=self._listen_loop, daemon=True)
        thread.start()

    def stop_listening(self):
        self.running = False

    def _listen_loop(self):
        while self.running:
            if self.ser.in_waiting:
                data = self.ser.read_until(b'\x55')  # 默认帧尾是 0x55
                if data.startswith(b'\xAA'):
                    cmd_type = data[1]
                    if cmd_type == 0x01:
                        self._handle_command("START")
                    elif cmd_type == 0x02:
                        result = data[2]
                        self._handle_command("RESULT", result)
                    elif cmd_type == 0x03:
                        self._handle_command("ERROR")

    def _handle_command(self, cmd_type, value=None):
        if cmd_type in self.callbacks:
            self.callbacks[cmd_type](value)

    def close(self):
        self.ser.close()
