import cv2
from backend.color_detector import ColorDetector
from backend.pattern_classifier.pattern_angle_predictor import PatternAndAngleClassifier
from typing import Dict

class VisionRecognitionService:
    def __init__(self,
                 angle_model_path: str = "proto_angle_final.pt",
                 enable_color: bool = True,
                 enable_pattern: bool = True):
        """
        初始化视觉识别服务
        """
        self.color_enabled = enable_color
        self.pattern_enabled = enable_pattern

        if self.color_enabled:
            self.color_detector = ColorDetector()

        if self.pattern_enabled:
            self.pattern_classifier = PatternAndAngleClassifier(model_path=angle_model_path)

    def predict_all(self, image) -> Dict:
        """
        输入：OpenCV格式的图像（BGR）
        输出：包含颜色识别、图案识别、角度预测的结果字典
        """
        result = {}

        if self.color_enabled:
            try:
                result["color"] = self.color_detector.detect_color(image)
            except Exception as e:
                result["color"] = "识别错误"
                result["color_error"] = str(e)

        if self.pattern_enabled:
            try:
                pattern, angle = self.pattern_classifier.predict(image)
                result["pattern"] = pattern
                result["angle"] = angle
            except Exception as e:
                result["pattern"] = "识别错误"
                result["angle"] = -1
                result["pattern_error"] = str(e)

        return result




